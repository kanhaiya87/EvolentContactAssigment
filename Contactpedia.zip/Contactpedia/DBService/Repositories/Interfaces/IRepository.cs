﻿using Contactpedia.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Contactpedia.Repositories.Interfaces
{
	public interface IRepository<T> where T : ParentEntity
	{
		IEnumerable<T> All();

		IEnumerable<T> FindByFilter(Expression<Func<T, bool>> predicate);

		T Create(T entity);

		void Update(T entity);

		T Delete(T entity);

		Task<int?> Save();
	}
}
