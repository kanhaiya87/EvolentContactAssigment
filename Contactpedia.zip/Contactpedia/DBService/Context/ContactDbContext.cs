﻿using System.Data.Entity;

namespace Contactpedia.Models
{
	public class ContactDbContext : DbContext
	{
		public ContactDbContext(string connectionString) : base(connectionString)
		{

		}

		protected override void OnModelCreating(DbModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);
		}
		
		public virtual DbSet<ContactInformation> ContactInformations { get; set; }
	}
}
