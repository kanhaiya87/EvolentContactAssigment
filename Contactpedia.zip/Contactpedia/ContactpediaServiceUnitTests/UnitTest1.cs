using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System.IO;
using Contactpedia.Models;
using Contactpedia.Controllers;
using Contactpedia.Repositories.Interfaces;
using Moq;
using System.Collections.Generic;
using System;
using System.Linq.Expressions;

namespace ContactpediaServiceUnitTests
{
	[TestClass]
	public class UnitTest1
	{
		/// <summary>
		///  configuration
		/// </summary>
		private IOptions<AppSettings> _config;
		private ContactServiceController _contactController = default(ContactServiceController);
		private Mock<IRepository<ContactInformation>> _contactRepository = null;

		[TestInitialize]
		public void Initialize()
		{
			var configuration = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("appsettings.json", false).Build();
			_config = Microsoft.Extensions.Options.Options.Create(configuration.GetSection("AppSettings")
				.Get<AppSettings>());
			_contactRepository = new Mock<IRepository<ContactInformation>>();
		}

		[TestMethod]
		public void ContactServiceController_GetContactList()
		{
			_contactRepository.Setup(repo => repo.All()).Returns(GetMockContactList());
			IEnumerable<ContactInformation> contactList = _contactController.GetContactList();


			Assert.IsNotNull(contactList);
			//Assert.IsTrue(contactList.Count == 10, "Couldn't test Get ContactList method");
		}

		[TestMethod]
		public void ContactServiceController_GetContact()
		{
			//_contactRepository.Setup(repo => repo.FindByFilter(It.IsAny<Expression<Func<ContactInformation, bool>>>())).Returns(GetMockContactList().FirstOrDefault());
			ContactInformation contact = _contactController.GetContact(1);
			Assert.IsNotNull(contact);
			Assert.IsTrue(contact.Id == 1, "Coulnd't find the requested contact details");
		}

		[TestMethod]
		public void ContactServiceController_CreateContact()
		{
			ContactInformation contact = GetContact();
			_contactRepository.Setup(repo => repo.Create(It.IsAny<ContactInformation>())).Returns(contact);
			ContactInformation newContact = _contactController.PostContact("add", contact);
			Assert.IsNotNull(newContact);
			Assert.AreEqual<ContactInformation>(newContact, contact, "contact couldn't be created");
		}

		[TestMethod]
		public void ContactServiceController_UpdateContact()
		{
			ContactInformation contact = GetContact();
			_contactRepository.Setup(repo => repo.Create(It.IsAny<ContactInformation>())).Returns(contact);
			ContactInformation newContact = _contactController.PostContact("update", contact);
			Assert.IsNotNull(newContact);
			Assert.AreEqual<ContactInformation>(newContact, contact,  "contact couldn't be updated");
		}

		[TestMethod]
		public void ContactServiceController_DeleteContact()
		{
			ContactInformation contact = GetContact();
			_contactRepository.Setup(repo => repo.Create(It.IsAny<ContactInformation>())).Returns(default(ContactInformation));
			ContactInformation newContact = _contactController.PostContact("delete", contact);
			Assert.IsNull(newContact);
		}

		private List<ContactInformation> GetMockContactList()
		{
			List<ContactInformation> contactList = new List<ContactInformation>();
			for (int i = 1; i < 11; i++)
			{
				contactList.Add(new ContactInformation
				{
					Id = i,
					FirstName = $"firstname{i}",
					LastName = $"firstname{i}",
					Email = $"email{i}@mail.com",
					Phone = $"999999999{i}"
				});
			}
			return contactList;
		}

		private static ContactInformation GetContact()
		{
			return new ContactInformation
			{
				FirstName = $"firstnameUTC",
				LastName = $"firstnameUTC",
				Email = $"emailUTC@mail.com",
				Phone = $"999999999UTC"
			};
		}

	}
}
