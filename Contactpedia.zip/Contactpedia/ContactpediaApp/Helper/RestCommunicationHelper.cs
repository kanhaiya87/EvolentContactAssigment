﻿using Newtonsoft.Json;
using RestSharp;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace ContactpediaApp.Helper
{
	public class RestCommunicationHelper
	{
		/// <summary>
		/// Execute Request
		/// </summary>
		/// <param name="requestParameters">Headers required for the REST call</param>
		/// <param name="baseURL">The base URL of the REST API</param>
		/// <param name="uri">The URI of the REST APIRequestType here is the REST Verbs (GET, PUT, PATCH, POST, DELETE)</param>
		/// <param name="requestType"></param>
		/// <param name="body">body of the request, empty for get type of request</param>
		/// <returns></returns>
		public static string ExecuteRequest(IEnumerable<KeyValuePair<string, string>> requestParameters, string baseURL, string uri, Method requestType, string action = "", string body = "")
		{
			string responseString = string.Empty;
			var restClient = new RestClient(baseURL);
			var request = new RestRequest(uri, requestType);
			var response = new RestResponse();

			// add body if it is not empty
			if (!string.IsNullOrEmpty(body))
			{
				var postdata = JsonConvert.DeserializeObject(body);
				request.AddJsonBody(postdata);
			}

			// add request headers if its not null
			if (requestParameters != null)
				foreach (var item in requestParameters)
					request.AddParameter(item.Key, item.Value, ParameterType.HttpHeader);

			// this will run the task asynchronously
			Task.Run(async () =>
			{
				response = await GetResponseContentAsync(restClient, request) as RestResponse;
			}).Wait();

			if (response != null)
				responseString = response.Content;

			// add the response string if the status code is ok
			if (response.StatusCode == HttpStatusCode.OK)
			{
				//success
			}
			else
			{
				//error
			}

			return responseString;
		}

		/// <summary>
		/// This method will get execute the request and get the response asynchronously
		/// </summary>
		/// <param name="theClient">client inforamtion object</param>
		/// <param name="theRequest">rest request object</param>
		/// <returns></returns>
		public static Task<IRestResponse> GetResponseContentAsync(RestClient theClient, RestRequest theRequest)
		{
			var tcs = new TaskCompletionSource<IRestResponse>();
			theClient.ExecuteAsync(theRequest, response => { tcs.SetResult(response); });
			return tcs.Task;
		}
	}
}
