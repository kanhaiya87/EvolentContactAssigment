﻿using Contactpedia.Models;
using Contactpedia.Repositories;
using Contactpedia.Repositories.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Contactpedia
{
	public class Startup
	{
		public Startup(IConfiguration configuration)
		{
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{
			services.Configure<AppSettings>(Configuration.GetSection("AppSettings"));
			services.AddOptions();
			services.AddMvc();

			var connection = @"Server = local; Database = UserContactDB; user id = test; password = test123; MultipleActiveResultSets = true;";
			services.AddDbContext<ContactDbContext>(options => options.UseSqlServer(connection));

			services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
		}

		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IHostingEnvironment env)
		{
			if (env.IsDevelopment())
				app.UseDeveloperExceptionPage();

			app.UseMvc();
		}
	}
}
