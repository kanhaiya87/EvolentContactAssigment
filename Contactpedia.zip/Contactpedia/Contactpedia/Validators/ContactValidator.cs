﻿using Contactpedia.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Contactpedia.Validators
{
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ContactFirstNameValidator: ValidationAttribute
	{
		protected override ValidationResult IsValid(object value, ValidationContext validationContext)
		{
			ContactInformation contact = (ContactInformation)validationContext.ObjectInstance;

			if (string.IsNullOrWhiteSpace(contact.FirstName))
				return new ValidationResult("Enter first name");

			if (contact.FirstName.Length > 30)
				return new ValidationResult("First name shouldn't exceed 30 characters");

			return ValidationResult.Success;
		}
	}
}
