﻿namespace Contactpedia.Models
{
	public class ConnectionString
	{
		public string Connection { get; set; }

	}
}
