﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace Contactpedia.Models
{
	public class ParentEntity
	{
		public int Id { get; set; }
		
		[DefaultValue(true)]
		public bool Active { get; set; }
	}
}
