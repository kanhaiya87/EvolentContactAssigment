﻿using Contactpedia.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Contactpedia.Models
{
    public class ContactInformation: ParentEntity
	{
		[ContactFirstNameValidator]
		public string FirstName { get; set; }
		
		[StringLength(30, ErrorMessage = "Last Name cannot Exceed 30 Character length")]
		[Required(ErrorMessage = "Enter last name")]
		public string LastName { get; set; }

		[StringLength(200)]
		[RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Enter valid email address")]
		public string Email { get; set; }

		[RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Enter valid Phone Number")]
		public string Phone { get; set; }

	}
}
