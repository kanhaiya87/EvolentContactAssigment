﻿using Microsoft.EntityFrameworkCore;

namespace Contactpedia.Models
{
	public class ContactDbContext : DbContext
	{
		public ContactDbContext(DbContextOptions<ContactDbContext> options) : base(options)
		{

		}
		public virtual DbSet<ContactInformation> ContactInformation { get; set; }
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);
		}
		
	}
}
