﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Contactpedia.Models
{
	public class AppSettings
	{
		public ConnectionString ConnectionString { get; set; }
	}
}
