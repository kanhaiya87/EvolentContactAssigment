﻿using Contactpedia.Models;
using Contactpedia.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Collections.Generic;
using System.Linq;

namespace Contactpedia.Controllers
{
	[Route("api/ContactService")]
	public class ContactServiceController : Controller
	{
		private IOptions<AppSettings> _appSettings = null;
		private IRepository<ContactInformation> _contactRepository = null;
		public ContactServiceController(IOptions<AppSettings> appSettings, IRepository<ContactInformation> repository)
		{
			_appSettings = appSettings;
			_contactRepository = repository;
		}

		// GET api/ContactsService
		[HttpGet]
		public List<ContactInformation> GetContactList()
		{
			List<ContactInformation> contactList = _contactRepository.All().ToList();
			return contactList;
		}

		// GET api/ContactsService/5
		[HttpGet("{id}")]
		public ContactInformation GetContact(int id)
		{
			return _contactRepository.FindByFilter(a => a.Id == id).FirstOrDefault();
		}

		// POST api/ContactsService
		[HttpPost]
		//[Route("api/PostContact?{requestType}")]
		public ContactInformation PostContact([FromQuery]string requestType, [FromBody]ContactInformation contact)
		{
			//string action = string.Empty;
			//ContactInformation contact = default(ContactInformation);
			ContactInformation postedContact = default(ContactInformation);
			switch (requestType)
			{
				case "add":
				postedContact = _contactRepository.Create(contact);
				break;
				case "update":
				postedContact = _contactRepository.Update(contact);
				break;
				case "delete":
				postedContact = _contactRepository.Delete(contact);
				break;
			}
			int returnResult = 0;
			if (postedContact != null)
				returnResult = _contactRepository.Save();

			return postedContact;
		}
	}
}
