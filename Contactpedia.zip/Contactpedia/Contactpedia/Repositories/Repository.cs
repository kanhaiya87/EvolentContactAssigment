﻿using Contactpedia.Models;
using Contactpedia.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Contactpedia.Repositories
{
	public class Repository<T> : IRepository<T>
	  where T : ParentEntity
	{
		private ContactDbContext context;
		protected readonly DbSet<T> _dbset;

		public Repository(ContactDbContext context)
		{
			this.context = context;
			this._dbset = context.Set<T>();
		}

		public virtual IEnumerable<T> All()
		{
			return _dbset.AsEnumerable();
		}

		public virtual IEnumerable<T> FindByFilter(Expression<Func<T, bool>> predicate)
		{
			IEnumerable<T> query = _dbset.Where(predicate).AsEnumerable();
			return query;
		}

		public virtual T Create(T entity)
		{
			return context.Set<T>().Add(entity).Entity;
		}

		public virtual T Update(T entity)
		{
			context.Entry(entity).State = EntityState.Modified;
			return entity;
		}

		public virtual T Delete(T entity)
		{
			return context.Set<T>().Remove(entity).Entity;
		}

		public  int Save()
		{
			return context.SaveChanges();
		}

		public void Dispose()
		{
			context.Dispose();
		}
	}
}
